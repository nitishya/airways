import { Component } from '@angular/core';

@Component({
  selector: 'app-lounge-card',
  templateUrl: './lounge-card.component.html',
  styleUrls: ['./lounge-card.component.scss'],
})
export class LoungeCardComponent    {

  constructor() { }

}
